from django.apps import AppConfig


class InternAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Intern_app'
